SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `lyrics_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(90) NOT NULL,
  `artist` varchar(90) NOT NULL,
  `album` varchar(90) NOT NULL DEFAULT 'Single',
  `lyrics` longtext NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `views` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lyrics_tbl` (`id`, `user_id`, `title`, `artist`, `album`, `lyrics`, `date_created`, `views`) VALUES
(1, 1, 'Design Your Tragedy', 'Greet The End', 'EP', 'Intro:\nWhy make your life so difficult\nTrapped in your own miserable world\nSurely it\'s not blessing, it\'s curse\nDig deep and find your inner voice\n\nYou hold your own universe. This life has no f*cking way out.\n\nVerse 1:\nYou will meander of your own fate\nYou have become what you always hate\nTime is running out better not wait\nthere is no other way\n\nYou will meander of your own fate\nYou have become what you always hate\nTime is running out better not wait\nthere is no other way\n\nChorus:\nDESTROY YOU!\nAgain and again!\nBE REBORN!\nDESTROY YOU!\nAgain and again!\nBE REBORN!\n\nBE REBORN!\n\nBe a king or a street sweeper,\neveryone dances with the grim reaper.\n\nVerse 2:\nWhat is the meaning of this existence?\nOur will to continue a dark chance in life\nWhat is the meaning of this existence?\nOur will to continue a dark chance in life\n\nChorus:\nDESTROY YOU!\nAgain and again!\nBE REBORN!\nDESTROY YOU!\nAgain and again!\nBE REBORN!\n\nEndless cycle of desire\nWhy can we face the meloncholic honesty\nWe are merely speck of dust dancing in our graves\nSelf deception and arrogance\nHumility did not get any chance\nwhat is the point?\nNothing!\n\nWhat is the meaning of this existence?\nOur will to continue a dark chance in life', '2021-07-12 18:42:03', 0),
(2, 1, 'Lovesong', '911', 'EP', 'Intro:\r\nWhy make your life so difficult\r\nTrapped in your own miserable world\r\nSurely it\'s not blessing, it\'s curse\r\nDig deep and find your inner voice\r\n\r\nYou hold your own universe. This life has no f*cking way out.\r\n\r\nVerse 1:\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nBE REBORN!\r\n\r\nBe a king or a street sweeper,\r\neveryone dances with the grim reaper.\r\n\r\nVerse 2:\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nEndless cycle of desire\r\nWhy can we face the meloncholic honesty\r\nWe are merely speck of dust dancing in our graves\r\nSelf deception and arrogance\r\nHumility did not get any chance\r\nwhat is the point?\r\nNothing!\r\n\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life', '2021-07-12 18:42:03', 0),
(3, 1, 'Let it go', 'Behemoth', 'EP', 'Intro:\r\nWhy make your life so difficult\r\nTrapped in your own miserable world\r\nSurely it\'s not blessing, it\'s curse\r\nDig deep and find your inner voice\r\n\r\nYou hold your own universe. This life has no f*cking way out.\r\n\r\nVerse 1:\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nBE REBORN!\r\n\r\nBe a king or a street sweeper,\r\neveryone dances with the grim reaper.\r\n\r\nVerse 2:\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nEndless cycle of desire\r\nWhy can we face the meloncholic honesty\r\nWe are merely speck of dust dancing in our graves\r\nSelf deception and arrogance\r\nHumility did not get any chance\r\nwhat is the point?\r\nNothing!\r\n\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life', '2021-07-12 18:42:03', 0),
(4, 1, 'My Heart will go on', 'Lamb of God', 'EP', 'Intro:\r\nWhy make your life so difficult\r\nTrapped in your own miserable world\r\nSurely it\'s not blessing, it\'s curse\r\nDig deep and find your inner voice\r\n\r\nYou hold your own universe. This life has no f*cking way out.\r\n\r\nVerse 1:\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nBE REBORN!\r\n\r\nBe a king or a street sweeper,\r\neveryone dances with the grim reaper.\r\n\r\nVerse 2:\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nEndless cycle of desire\r\nWhy can we face the meloncholic honesty\r\nWe are merely speck of dust dancing in our graves\r\nSelf deception and arrogance\r\nHumility did not get any chance\r\nwhat is the point?\r\nNothing!\r\n\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life', '2021-07-12 18:42:03', 69),
(6, 1, 'Abbearance', 'Siakol', '', 'asdasdasdasddasdasdasdasdasdasdasdasddasdasdasdasddasdasdasdasdasdasdasdasddasdasdasdasd', '2021-07-13 15:13:41', 0),
(7, 1, 'Abbearances', 'Greet The End', 'Single', 'Intro:\r\nWhy make your life so difficult\r\nTrapped in your own miserable world\r\nSurely it\'s not blessing, it\'s curse\r\nDig deep and find your inner voice\r\n\r\nYou hold your own universe. This life has no f*cking way out.\r\n\r\nVerse 1:\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nBE REBORN!\r\n\r\nBe a king or a street sweeper,\r\neveryone dances with the grim reaper.\r\n\r\nVerse 2:\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nEndless cycle of desire\r\nWhy can we face the meloncholic honesty\r\nWe are merely speck of dust dancing in our graves\r\nSelf deception and arrogance\r\nHumility did not get any chance\r\nwhat is the point?\r\nNothing!\r\n\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in lifeIntro:\r\nWhy make your life so difficult\r\nTrapped in your own miserable world\r\nSurely it\'s not blessing, it\'s curse\r\nDig deep and find your inner voice\r\n\r\nYou hold your own universe. This life has no f*cking way out.\r\n\r\nVerse 1:\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nYou will meander of your own fate\r\nYou have become what you always hate\r\nTime is running out better not wait\r\nthere is no other way\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nBE REBORN!\r\n\r\nBe a king or a street sweeper,\r\neveryone dances with the grim reaper.\r\n\r\nVerse 2:\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in life\r\n\r\nChorus:\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\nDESTROY YOU!\r\nAgain and again!\r\nBE REBORN!\r\n\r\nEndless cycle of desire\r\nWhy can we face the meloncholic honesty\r\nWe are merely speck of dust dancing in our graves\r\nSelf deception and arrogance\r\nHumility did not get any chance\r\nwhat is the point?\r\nNothing!\r\n\r\nWhat is the meaning of this existence?\r\nOur will to continue a dark chance in lifedasdasdasdasd', '2021-07-13 15:15:16', 0),
(13, 1, 'To the Hellfire', 'Moira Dela Tora', 'Single', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eleifend lorem feugiat interdum vulputate. Vivamus non purus blandit, bibendum purus sit amet, dapibus mi. Sed vel ligula nunc. Nam nec lorem volutpat, tincidunt lorem quis, convallis odio. Quisque ultricies nisi a elit pharetra, ultricies ultrices erat sagittis. Proin mi quam, rutrum ac ipsum et, posuere rutrum est. Nam aliquam dignissim nisi, nec ullamcorper risus auctor vehicula. Donec suscipit nisi nec nisl commodo pellentesque. Cras vel diam est.\r\n\r\nAliquam hendrerit tempus suscipit. Donec purus tellus, lacinia sed mattis in, molestie non sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque blandit, urna non malesuada vehicula, augue arcu congue justo, sed feugiat arcu metus eu lorem. Fusce mollis est felis, vitae interdum quam molestie nec. Vestibulum ut egestas risus. Donec sed ante nulla. Nam at lectus at augue condimentum ultrices. Phasellus in nibh eu metus semper tempus vel vel sem. Nam non sapien eget nunc accumsan dignissim. Curabitur nulla nisl, luctus quis condimentum interdum, eleifend vel metus.\r\n\r\nSed pretium molestie odio vitae tristique. Integer ac leo ipsum. Fusce non orci sed ligula condimentum rhoncus eu sed turpis. Sed sed magna ac magna tempor pretium non vel nunc. Aliquam ac tortor in nisi pretium sodales dignissim non ligula. Sed quis metus in diam aliquet varius vitae vitae eros. Phasellus eros elit, ullamcorper in metus et, lacinia sodales arcu. Nunc non faucibus felis, eu placerat metus. Sed vitae ullamcorper purus. Nunc at odio id orci malesuada bibendum. Proin laoreet lectus lacus, non feugiat dolor rhoncus sit amet. In eu gravida dolor. Nam ante odio, pretium id odio sed, egestas accumsan turpis. Praesent porta molestie leo, quis ultrices risus aliquam non.', '2021-07-13 16:35:41', 0);

CREATE TABLE `useraccounts` (
  `id` int(90) NOT NULL,
  `username` varchar(90) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `useraccounts` (`id`, `username`, `password`, `email`) VALUES
(1, 'kjnabus', '5e8ff9bf55ba3508199d22e984129be6', 'prjzhiraj@gmail.com'),
(2, 'japlapunggot', '96f0f08c0188ba04898ce8cc465c19c4', 'jeeryl@gmail.com');

CREATE TABLE `userdetails` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fname` varchar(90) NOT NULL,
  `sname` varchar(90) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `about` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `userdetails` (`id`, `user_id`, `fname`, `sname`, `gender`, `about`) VALUES
(1, 1, 'Kristian', 'Nabus', 'Male', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur ut fringilla urna. Fusce risus ipsum, ultricies pharetra tempor sit amet, finibus eu elit. Suspendisse maximus dignissim enim, a tristique nulla laoreet in. Nam et euismod augue. Quisque tortor mi, ullamcorper a porttitor sed, lobortis vel ipsum. Mauris sollicitudin, dolor ut cursus sodales, neque nulla vulputate elit, ut posuere lorem nisi auctor risus. Fusce varius nibh vitae leo maximus feugiat. Sed a mi facilisis, elementum eros tincidunt, posuere dolor.\r\n\r\nFusce vitae velit magna. Donec pretium sodales urna eget scelerisque. Nulla id tincidunt nisl. Suspendisse nisl mi, mollis sed luctus nec, sodales eget quam. Mauris scelerisque sagittis velit eu vehicula. Mauris pellentesque, dui quis feugiat rutrum, odio massa rhoncus est, at rutrum nulla dolor eu nisl. Vivamus in velit in quam pulvinar molestie eu commodo ligula. Nullam a varius magna. Suspendisse fermentum egestas fringilla. Quisque condimentum diam sit amet quam feugiat eleifend. Vestibulum ex arcu, mattis ut accumsan sit amet, eleifend et ligula. Maecenas ac mauris erat. Curabitur pretium porttitor ligula, vel iaculis velit tempor non.'),
(2, 2, 'Jerry', 'Lapunggot', 'Female', '');


ALTER TABLE `lyrics_tbl`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);


ALTER TABLE `lyrics_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `useraccounts`
  MODIFY `id` int(90) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `userdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
